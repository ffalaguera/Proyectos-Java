CREATE TABLE aerolineas (
    id_aerolinea INT PRIMARY KEY,
    nombre VARCHAR(100),
    pais_origen VARCHAR(50),
    anio_fundacion INT,
	flota_activa INT,
    pagina_web VARCHAR(200)
);


CREATE TABLE aviones (
    id_avion INT PRIMARY KEY,
    modelo VARCHAR(50),
    capacidad_pasajeros INT,
	alcance_km INT,
    anio_fabricacion INT,
    id_aerolinea INT,
    FOREIGN KEY (id_aerolinea) REFERENCES aerolineas(id_aerolinea)
);


CREATE TABLE vuelos (
    id_vuelo VARCHAR(10) PRIMARY KEY,
    origen VARCHAR(50),
    destino VARCHAR(50),
    fecha_salida DATE,
    id_avion INT,
    id_aerolinea INT,
    estado VARCHAR(20),
	duracion_min INT,
    FOREIGN KEY (id_avion) REFERENCES aviones(id_avion),
    FOREIGN KEY (id_aerolinea) REFERENCES aerolineas(id_aerolinea)
);


CREATE TABLE pasajeros (
    id_pasajero INT PRIMARY KEY,
    nombre VARCHAR(100),
    edad INT,
    pasaporte VARCHAR(20),
    nacionalidad VARCHAR(50),
    id_vuelo VARCHAR(10),
	clase VARCHAR(20),
    asiento VARCHAR(5),
    FOREIGN KEY (id_vuelo) REFERENCES vuelos(id_vuelo)
);

CREATE TABLE equipaje (
    id_equipaje VARCHAR(20) PRIMARY KEY,
    tipo VARCHAR(10),
    peso_kg DECIMAL(5,2),
    dimensiones VARCHAR(20),
    id_pasajero INT,
    FOREIGN KEY (id_pasajero) REFERENCES pasajeros(id_pasajero)
);