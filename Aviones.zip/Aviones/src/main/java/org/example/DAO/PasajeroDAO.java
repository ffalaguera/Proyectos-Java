package org.example.DAO;


import org.example.POJO.Equipaje;
import org.example.POJO.Pasajero;
import org.example.DAO.ConexionBD;

import javax.xml.namespace.QName;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import java.sql.SQLException;

public class PasajeroDAO {

    public void updatePasajero(Pasajero p) {

        String sqlUpdatePasajero = "UPDATE pasajeros SET nombre =?, edad =?, pasaporte =?, nacionalidad =?," +
                " id_vuelo =?, clase =?, asiento =? WHERE id_pasajero =?;";
        String sqlDeleteEquipaje = "DELETE FROM equipaje WHERE id_pasajero =?;";
        String sqlInsertEquipaje = "INSERT INTO equipaje (id_equipaje, tipo, peso_kg, dimensiones, id_pasajero) VALUES(?,?,?,?,?);";


        Connection conn = null;
        try {
            conn = ConexionBD.getConnection();
            conn.setAutoCommit(false);

            try (PreparedStatement psUpdatePasajero = conn.prepareStatement(sqlUpdatePasajero)) {

                psUpdatePasajero.setString(1, p.getNombre());
                psUpdatePasajero.setInt(2, p.getEdad());
                psUpdatePasajero.setString(3, p.getPasaporte());
                psUpdatePasajero.setString(4, p.getNacionalidad());
                psUpdatePasajero.setString(5, p.getId_vuelo());
                psUpdatePasajero.setString(6, p.getClase());
                psUpdatePasajero.setString(7, p.getAsiento());
                psUpdatePasajero.setInt(8, p.getId_pasajero());

                psUpdatePasajero.executeUpdate();
            }
            try (PreparedStatement psDeleteEquipaje = conn.prepareStatement(sqlDeleteEquipaje)) {
                psDeleteEquipaje.setInt(1, p.getId_pasajero());
                psDeleteEquipaje.executeUpdate();
            }
            for (Equipaje equipaje : p.getEquipaje()) {
                try (PreparedStatement psInsertEquipaje = conn.prepareStatement(sqlInsertEquipaje)) {
                    psInsertEquipaje.setString(1, equipaje.getId_equipaje());
                    psInsertEquipaje.setString(2, equipaje.getTipo());
                    psInsertEquipaje.setDouble(3, equipaje.getPeso_kg());
                    psInsertEquipaje.setString(4, equipaje.getDimensiones());
                    psInsertEquipaje.setInt(5, p.getId_pasajero());

                    psInsertEquipaje.executeUpdate();
                }
            }
            conn.commit();
        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void deletePasajero(Pasajero p) {
        String sqlDeleteEquipaje = "DELETE FROM equipaje WHERE id_pasajero =?;";
        String sqlDeletePasajero = "DELETE FROM pasajeros WHERE id_pasajero = ?;";

        Connection conn = null;

        try {
            conn = ConexionBD.getConnection();
            conn.setAutoCommit(false);

            try (PreparedStatement psDeleteEquipaje = conn.prepareStatement(sqlDeleteEquipaje)) {
                psDeleteEquipaje.setInt(1, p.getId_pasajero());
                psDeleteEquipaje.executeUpdate();
            }
            try (PreparedStatement psDeletePasajero = conn.prepareStatement(sqlDeletePasajero)) {
                psDeletePasajero.setInt(1, p.getId_pasajero());
                psDeletePasajero.executeUpdate();
            }
            conn.commit();
        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public List<Pasajero> getAllPasajeros() {
        String sqlPasajero = "SELECT * FROM pasajeros;";
        String sqlEquipaje = "SELECT * FROM equipaje WHERE id_pasajero = ?;";
        List<Pasajero> pasajeros = new ArrayList<>();

        Connection conn = null;
        try {
            conn = ConexionBD.getConnection();

            try (PreparedStatement psPasajero = conn.prepareStatement(sqlPasajero)) {
                try (ResultSet rs = psPasajero.executeQuery()) {
                    while (rs.next()) {
                        Pasajero p = new Pasajero(

                                rs.getInt("id_pasajero"),
                                rs.getString("nombre"),
                                rs.getInt("edad"),
                                rs.getString("pasaporte"),
                                rs.getString("nacionalidad"),
                                rs.getString("id_vuelo"),
                                rs.getString("clase"),
                                rs.getString("clase"),
                                new ArrayList<>()
                        );
                        try (PreparedStatement psEquipaje = conn.prepareStatement(sqlEquipaje)) {
                            psEquipaje.setInt(1, p.getId_pasajero());
                            try (ResultSet rsEquipaje = psEquipaje.executeQuery()) {
                                while (rsEquipaje.next()) {
                                    Equipaje e = new Equipaje(
                                            rsEquipaje.getString("id_equipaje"),
                                            rsEquipaje.getString("tipo"),
                                            rsEquipaje.getDouble("peso_kg"),
                                            rsEquipaje.getString("dimensiones"),
                                            rsEquipaje.getInt("id_pasajero")
                                    );
                                    p.getEquipaje().add(e);
                                }
                            }
                        }
                        pasajeros.add(p);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return pasajeros;
    }
}
