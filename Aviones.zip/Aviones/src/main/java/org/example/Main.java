package org.example;


import org.example.DAO.PasajeroDAO;
import org.example.POJO.Pasajero;
import org.example.jsonParser.Parser.Parser;

import java.util.List;

public class Main {

    public static void main(String[] args) {
        String fichero = "aviones.json";

        PasajeroDAO pasajeroDAO = new PasajeroDAO();


        List<Pasajero> pasajeros = pasajeroDAO.getAllPasajeros();

        if (pasajeros == null || pasajeros.isEmpty()) {

            Parser.parsearJson(fichero);
        }

        if (pasajeros != null || pasajeros.isEmpty()) {
            System.out.println("Pasajeros de mas de 20 años: ");
            System.out.println("-".repeat(20));
            pasajeros.stream()
                    .filter(p -> p.getEdad() > 20)
                    .map(Pasajero::getNombre)
                    .sorted()
                    .forEach(System.out::println);
            System.out.println("*".repeat(50));
            System.out.println("Edad media de los pasajeros: ");
            System.out.println("-".repeat(20));
            double mediaEdad = pasajeros.stream()
                    .mapToInt(Pasajero::getEdad)
                    .average()
                    .orElse(0);
            System.out.println(mediaEdad);
            System.out.println("*".repeat(50));
            System.out.println("Pasajeros con nacionalidad Canadiense: ");
            System.out.println("-".repeat(20));
            long numCanadiense = pasajeros.stream()
                    .filter(p -> "Canadiense".equalsIgnoreCase(p.getNacionalidad()))
                    .count();
            System.out.println(numCanadiense);

        }
    }
}