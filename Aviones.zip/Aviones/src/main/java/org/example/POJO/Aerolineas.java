package org.example.POJO;

import java.util.List;

public class Aerolineas {
    private int id_aerolinea;
    private String nombre;
    private String pais_origen;
    private int anio_fundacion;
    private int flota_activa;
    private String pagina_web;

    public int getId_aerolinea() {
        return id_aerolinea;
    }

    public void setId_aerolinea(int id_aerolinea) {
        this.id_aerolinea = id_aerolinea;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPais_origen() {
        return pais_origen;
    }

    public void setPais_origen(String pais_origen) {
        this.pais_origen = pais_origen;
    }

    public int getAnio_fundacion() {
        return anio_fundacion;
    }

    public void setAnio_fundacion(int anio_fundacion) {
        this.anio_fundacion = anio_fundacion;
    }

    public int getFlota_activa() {
        return flota_activa;
    }

    public void setFlota_activa(int flota_activa) {
        this.flota_activa = flota_activa;
    }

    public String getPagina_web() {
        return pagina_web;
    }

    public void setPagina_web(String pagina_web) {
        this.pagina_web = pagina_web;
    }

    public Aerolineas() {

    }

    public Aerolineas(int id_aerolinea, String nombre, String pais_origen, int anio_fundacion, int flota_activa, String pagina_web) {
        this.id_aerolinea = id_aerolinea;
        this.nombre = nombre;
        this.pais_origen = pais_origen;
        this.anio_fundacion = anio_fundacion;
        this.flota_activa = flota_activa;
        this.pagina_web = pagina_web;
    }

    @Override
    public String toString() {
        return "Aerolineas{" +
                "id_aerolinea=" + id_aerolinea +
                ", nombre='" + nombre + '\'' +
                ", pais_origen='" + pais_origen + '\'' +
                ", anio_fundacion=" + anio_fundacion +
                ", flota_activa=" + flota_activa +
                ", pagina_web='" + pagina_web + '\'' +
                '}';
    }
}

