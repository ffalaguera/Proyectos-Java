package org.example.POJO;

public class Aviones {
    private int id_avion;
    private String modelo;
    private int capacidad_pasajeros;
    private int alcance_km;
    private int anio_fabricacion;
    private int id_aerolinea;

    public int getId_avion() {
        return id_avion;
    }

    public void setId_avion(int id_avion) {
        this.id_avion = id_avion;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getCapacidad_pasajeros() {
        return capacidad_pasajeros;
    }

    public void setCapacidad_pasajeros(int capacidad_pasajeros) {
        this.capacidad_pasajeros = capacidad_pasajeros;
    }

    public int getAlcance_km() {
        return alcance_km;
    }

    public void setAlcance_km(int alcance_km) {
        this.alcance_km = alcance_km;
    }

    public int getAnio_fabricacion() {
        return anio_fabricacion;
    }

    public void setAnio_fabricacion(int anio_fabricacion) {
        this.anio_fabricacion = anio_fabricacion;
    }

    public int getId_aerolinea() {
        return id_aerolinea;
    }

    public void setId_aerolinea(int id_aerolinea) {
        this.id_aerolinea = id_aerolinea;
    }

    public Aviones() {

    }

    public Aviones(int id_avion, String modelo, int capacidad_pasajeros, int alcance_km, int anio_fabricacion, int id_aerolinea) {
        this.id_avion = id_avion;
        this.modelo = modelo;
        this.capacidad_pasajeros = capacidad_pasajeros;
        this.alcance_km = alcance_km;
        this.anio_fabricacion = anio_fabricacion;
        this.id_aerolinea = id_aerolinea;
    }

    @Override
    public String toString() {
        return "Aviones{" +
                "id_avion=" + id_avion +
                ", modelo='" + modelo + '\'' +
                ", capacidad_pasajeros=" + capacidad_pasajeros +
                ", alcance_km=" + alcance_km +
                ", anio_fabricacion=" + anio_fabricacion +
                ", id_aerolinea=" + id_aerolinea +
                '}';
    }
}
