package org.example.POJO;

public class Equipaje {
    private String id_equipaje;
    private String tipo;
    private double peso_kg;
    private String dimensiones;
    private int id_pasajero;

    public String getId_equipaje() {
        return id_equipaje;
    }

    public void setId_equipaje(String id_equipaje) {
        this.id_equipaje = id_equipaje;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getPeso_kg() {
        return peso_kg;
    }

    public void setPeso_kg(double peso_kg) {
        this.peso_kg = peso_kg;
    }

    public String getDimensiones() {
        return dimensiones;
    }

    public void setDimensiones(String dimensiones) {
        this.dimensiones = dimensiones;
    }

    public int getId_pasajero() {
        return id_pasajero;
    }

    public void setId_pasajero(int id_pasajero) {
        this.id_pasajero = id_pasajero;
    }

    public Equipaje() {

    }

    public Equipaje(String id_equipaje, String tipo, double peso_kg, String dimensiones, int id_pasajero) {
        this.id_equipaje = id_equipaje;
        this.tipo = tipo;
        this.peso_kg = peso_kg;
        this.dimensiones = dimensiones;
        this.id_pasajero = id_pasajero;
    }

    @Override
    public String toString() {
        return "Equipaje{" +
                "id_equipaje='" + id_equipaje + '\'' +
                ", tipo='" + tipo + '\'' +
                ", peso_kg=" + peso_kg +
                ", dimensiones='" + dimensiones + '\'' +
                ", id_pasajero=" + id_pasajero +
                '}';
    }
}
