package org.example.POJO;

import java.util.List;

public class Pasajero {
    private int id_pasajero;
    private String nombre;
    private int edad;
    private String pasaporte;
    private String nacionalidad;
    private String id_vuelo;
    private String clase;
    private String asiento;

    private List<Equipaje> equipaje;

    public int getId_pasajero() {
        return id_pasajero;
    }

    public void setId_pasajero(int id_pasajero) {
        this.id_pasajero = id_pasajero;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getPasaporte() {
        return pasaporte;
    }

    public void setPasaporte(String pasaporte) {
        this.pasaporte = pasaporte;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public String getId_vuelo() {
        return id_vuelo;
    }

    public void setId_vuelo(String id_vuelo) {
        this.id_vuelo = id_vuelo;
    }

    public String getClase() {
        return clase;
    }

    public void setClase(String clase) {
        this.clase = clase;
    }

    public String getAsiento() {
        return asiento;
    }

    public void setAsiento(String asiento) {
        this.asiento = asiento;
    }

    public List<Equipaje> getEquipaje() {
        return equipaje;
    }

    public void setEquipaje(List<Equipaje> equipaje) {
        this.equipaje = equipaje;
    }

    public Pasajero() {
    }

    public Pasajero(int id_pasajero, String nombre, int edad, String pasaporte, String nacionalidad,
                    String id_vuelo, String clase, String asiento, List<Equipaje> equipaje) {
        this.id_pasajero = id_pasajero;
        this.nombre = nombre;
        this.edad = edad;
        this.pasaporte = pasaporte;
        this.nacionalidad = nacionalidad;
        this.id_vuelo = id_vuelo;
        this.clase = clase;
        this.asiento = asiento;
        this.equipaje = equipaje;
    }
}
