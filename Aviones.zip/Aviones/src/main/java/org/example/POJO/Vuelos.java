package org.example.POJO;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

public class Vuelos {
    private String id_vuelo;
    private String origen;
    private String destino;
    private LocalDate fecha_salida;
    private int id_avion;
    private int id_aerolinea;
    private String estado;
    private int duracion_min;

    public String getId_vuelo() {
        return id_vuelo;
    }

    public void setId_vuelo(String id_vuelo) {
        this.id_vuelo = id_vuelo;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public LocalDate getFecha_salida() {
        return fecha_salida;
    }

    public void setFecha_salida(LocalDate fecha_salida) {
        this.fecha_salida = fecha_salida;
    }

    public int getId_avion() {
        return id_avion;
    }

    public void setId_avion(int id_avion) {
        this.id_avion = id_avion;
    }

    public int getId_aerolinea() {
        return id_aerolinea;
    }

    public void setId_aerolinea(int id_aerolinea) {
        this.id_aerolinea = id_aerolinea;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getDuracion_min() {
        return duracion_min;
    }

    public void setDuracion_min(int duracion_min) {
        this.duracion_min = duracion_min;
    }

    public Vuelos() {

    }

    public Vuelos(String id_vuelo, String origen, String destino, LocalDate fecha_salida, int id_avion, int id_aerolinea, String estado, int duracion_min) {
        this.id_vuelo = id_vuelo;
        this.origen = origen;
        this.destino = destino;
        this.fecha_salida = fecha_salida;
        this.id_avion = id_avion;
        this.id_aerolinea = id_aerolinea;
        this.estado = estado;
        this.duracion_min = duracion_min;
    }

    @Override
    public String toString() {
        return "Vuelos{" +
                "id_vuelo='" + id_vuelo + '\'' +
                ", origen='" + origen + '\'' +
                ", destino='" + destino + '\'' +
                ", fecha_salida=" + fecha_salida +
                ", id_avion=" + id_avion +
                ", id_aerolinea=" + id_aerolinea +
                ", estado='" + estado + '\'' +
                ", duracion_min=" + duracion_min +
                '}';
    }
}
