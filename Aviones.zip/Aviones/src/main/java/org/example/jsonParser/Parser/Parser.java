package org.example.jsonParser.Parser;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.example.DAO.ConexionBD;


import java.io.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;


public class Parser {
    private static final Gson gson = new Gson();

    private static String leerJson(String fichero) {
        try (BufferedReader br = new BufferedReader(new FileReader(fichero))) {
            StringBuilder response = new StringBuilder();
            String linea;
            while ((linea = br.readLine()) != null) {
                response.append(linea);
            }
            return response.toString();
        } catch (IOException e) {
            throw new Error("No se pudo leer el archivo " + e.getMessage());
        }
    }

    public static void parsearJson(String json) {
        Connection conn = null;
        try {
            conn = ConexionBD.getConnection();
            conn.setAutoCommit(false);

            String jsonResponse = leerJson(json);
            JsonObject jsonObject = gson.fromJson(jsonResponse, JsonObject.class);

            JsonArray aerolineasArray = jsonObject.getAsJsonArray("aerolineas");
            for (var element : aerolineasArray) {
                JsonObject aerolineaData = element.getAsJsonObject();

                int id = aerolineaData.get("id_aerolinea").getAsInt();
                String nombre = aerolineaData.get("nombre").getAsString();
                String pais_origen = aerolineaData.get("pais_origen").getAsString();
                int anio_fundacion = aerolineaData.get("anio_fundacion").getAsInt();
                int flota_activa = aerolineaData.get("flota_activa").getAsInt();
                String pagina_web = aerolineaData.get("pagina_web").getAsString();

                String sqlAerolinea = "INSERT INTO aerolineas(id_aerolinea, nombre, pais_origen, anio_fundacion, flota_activa, pagina_web) VALUES (?,?,?,?,?,?);";
                String validarTabla = "SELECT COUNT(*) FROM aerolineas WHERE id_aerolinea = ?;";
                try(PreparedStatement psValidar = conn.prepareStatement(validarTabla)) {
                    psValidar.setInt(1, id);
                    ResultSet rsValidar = psValidar.executeQuery();
                    if (rsValidar.next() && rsValidar.getInt(1) == 0) {
                        try (PreparedStatement psAero = conn.prepareStatement(sqlAerolinea)) {
                            psAero.setInt(1, id);
                            psAero.setString(2, nombre);
                            psAero.setString(3, pais_origen);
                            psAero.setInt(4, anio_fundacion);
                            psAero.setInt(5, flota_activa);
                            psAero.setString(6, pagina_web);

                            psAero.executeUpdate();
                        }
                    }
                }
            }

            JsonArray avionesArray = jsonObject.getAsJsonArray("aviones");
            for (var element : avionesArray) {
                JsonObject avionData = element.getAsJsonObject();

                int id = avionData.get("id_avion").getAsInt();
                String modelo = avionData.get("modelo").getAsString();
                int capacidad_pasajeros = avionData.get("capacidad_pasajeros").getAsInt();
                int alcance_km = avionData.get("alcance_km").getAsInt();
                int anio_fabricacion = avionData.get("anio_fabricacion").getAsInt();
                int id_aerolinea = avionData.get("id_aerolinea").getAsInt();

                String sqlAviones = "INSERT INTO aviones(id_avion, modelo, capacidad_pasajeros, alcance_km, anio_fabricacion, id_aerolinea) VALUES (?,?,?,?,?,?);";
                String validarTabla = "SELECT COUNT(*) FROM aviones WHERE id_avion = ?;";
                try(PreparedStatement psValidar = conn.prepareStatement(validarTabla)) {
                    psValidar.setInt(1, id);
                    ResultSet rsValidar = psValidar.executeQuery();
                    if (rsValidar.next() && rsValidar.getInt(1) == 0) {
                        try (PreparedStatement psAvion = conn.prepareStatement(sqlAviones)) {
                            psAvion.setInt(1, id);
                            psAvion.setString(2, modelo);
                            psAvion.setInt(3, capacidad_pasajeros);
                            psAvion.setInt(4, alcance_km);
                            psAvion.setInt(5, anio_fabricacion);
                            psAvion.setInt(6, id_aerolinea);

                            psAvion.executeUpdate();
                        }
                    }
                }
            }

            JsonArray vuelosArray = jsonObject.getAsJsonArray("vuelos");
            for (var element : vuelosArray) {
                JsonObject vueloData = element.getAsJsonObject();

                String id = vueloData.get("id_vuelo").getAsString();
                String origen = vueloData.get("origen").getAsString();
                String destino = vueloData.get("destino").getAsString();
                String fecha_salida = vueloData.get("fecha_salida").getAsString();
                LocalDate fecha_salidaDate = LocalDate.parse(fecha_salida, DateTimeFormatter.ISO_LOCAL_DATE);
                Date fechaSql = Date.valueOf(fecha_salidaDate);
                int id_avion = vueloData.get("id_avion").getAsInt();
                int id_aerolinea = vueloData.get("id_aerolinea").getAsInt();
                String estado = vueloData.get("estado").getAsString();
                int duracion_min = vueloData.get("duracion_min").getAsInt();

                String sqlVuelos = "INSERT INTO vuelos(id_vuelo, origen, destino, fecha_salida, id_avion, id_aerolinea, estado, duracion_min) VALUES (?,?,?,?,?,?,?,?);";
                String validarTabla = "SELECT COUNT(*) FROM vuelos WHERE id_vuelo = ?;";
                try (PreparedStatement psValidar = conn.prepareStatement(validarTabla)) {
                    psValidar.setString(1, id);
                    ResultSet rsValidar = psValidar.executeQuery();
                    if (rsValidar.next() && rsValidar.getInt(1) == 0) {
                        try (PreparedStatement psVuelo = conn.prepareStatement(sqlVuelos)) {
                            psVuelo.setString(1, id);
                            psVuelo.setString(2, origen);
                            psVuelo.setString(3, destino);
                            psVuelo.setDate(4, fechaSql);
                            psVuelo.setInt(5, id_avion);
                            psVuelo.setInt(6, id_aerolinea);
                            psVuelo.setString(7, estado);
                            psVuelo.setInt(8, duracion_min);

                            psVuelo.executeUpdate();
                        }
                    }
                }
            }

            JsonArray pasajerosArray = jsonObject.getAsJsonArray("pasajeros");
            for (var element : pasajerosArray) {
                JsonObject pasajeroData = element.getAsJsonObject();

                int id = pasajeroData.get("id_pasajero").getAsInt();
                String nombre = pasajeroData.get("nombre").getAsString();
                int edad = pasajeroData.get("edad").getAsInt();
                String pasaporte = pasajeroData.get("pasaporte").getAsString();
                String nacionalidad = pasajeroData.get("nacionalidad").getAsString();
                String id_vuelo = pasajeroData.get("id_vuelo").getAsString();
                String clase = pasajeroData.get("clase").getAsString();
                String asiento = pasajeroData.get("asiento").getAsString();

                String sqlPasajeros = "INSERT INTO pasajeros(id_pasajero, nombre, edad, pasaporte, nacionalidad, id_vuelo, clase, asiento) VALUES (?,?,?,?,?,?,?,?);";
                String validarTabla = "SELECT COUNT(*) FROM pasajeros WHERE id_pasajero = ?;";
                try (PreparedStatement psValidar = conn.prepareStatement(validarTabla)) {
                    psValidar.setInt(1, id);
                    ResultSet rsValidar = psValidar.executeQuery();
                    if (rsValidar.next() && rsValidar.getInt(1) == 0) {
                        try (PreparedStatement psPasajero = conn.prepareStatement(sqlPasajeros)) {
                            psPasajero.setInt(1, id);
                            psPasajero.setString(2, nombre);
                            psPasajero.setInt(3, edad);
                            psPasajero.setString(4, pasaporte);
                            psPasajero.setString(5, nacionalidad);
                            psPasajero.setString(6, id_vuelo);
                            psPasajero.setString(7, clase);
                            psPasajero.setString(8, asiento);

                            psPasajero.executeUpdate();
                        }
                    }
                }

                JsonArray equipajesArray = pasajeroData.getAsJsonArray("equipaje");
                for (var element2 : equipajesArray) {
                    JsonObject obj2 = element2.getAsJsonObject();

                    String id_equipaje = obj2.get("id_equipaje").getAsString();
                    String tipo = obj2.get("tipo").getAsString();
                    double peso_kg = obj2.get("peso_kg").getAsDouble();
                    String dimensiones = obj2.get("dimensiones").getAsString();


                    String sqlEquipaje = "INSERT INTO equipaje(id_equipaje, tipo, peso_kg, dimensiones, id_pasajero) VALUES (?,?,?,?,?);";
                    validarTabla = "SELECT COUNT(*) FROM equipaje WHERE id_equipaje = ?;";
                    try (PreparedStatement psValidar = conn.prepareStatement(validarTabla)) {
                        psValidar.setString(1, id_equipaje);
                        ResultSet rsValidar = psValidar.executeQuery();
                        if (rsValidar.next() && rsValidar.getInt(1) == 0) {
                            try (PreparedStatement psEquipaje = conn.prepareStatement(sqlEquipaje)) {
                                psEquipaje.setString(1, id_equipaje);
                                psEquipaje.setString(2, tipo);
                                psEquipaje.setDouble(3, peso_kg);
                                psEquipaje.setString(4, dimensiones);
                                psEquipaje.setInt(5, id);

                                psEquipaje.executeUpdate();
                            }
                        }
                    }
                }
            }
            conn.commit();
        } catch (SQLException e) {
            if (conn != null) {
                try {
                    // Deshaz la actualización
                    conn.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    // Restaura el autoCommit a true
                    conn.setAutoCommit(true);
                    // Cierra la conexión
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
