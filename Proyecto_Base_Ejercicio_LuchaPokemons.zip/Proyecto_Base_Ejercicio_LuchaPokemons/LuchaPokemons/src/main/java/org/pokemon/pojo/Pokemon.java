package org.pokemon.pojo;

import javax.sound.sampled.*;
import java.io.BufferedInputStream;
import java.net.URI;
import java.net.URL;
import java.text.Normalizer;
import java.util.List;


public class Pokemon {
    private String name;
    private int id;
    private int height;
    private int weight;
    private String type;

    private List<Crie> crieList;

    private List<Form> formList;
    private List<Stat> stats;
    private List<Move> moves;
    private Ability ability;

    public Pokemon(String name, int id, int height, int weight, String type, List<Crie> crieList, List<Form> formList, List<Stat> stats, List<Move> moves, Ability ability) {
        this.name = name;
        this.id = id;
        this.height = height;
        this.weight = weight;
        this.type = type;
        this.crieList = crieList;
        this.formList = formList;
        this.stats = stats;
        this.moves = moves;
        this.ability = ability;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<Crie> getCrieList() {
        return crieList;
    }

    public void setCrieList(List<Crie> crieList) {
        this.crieList = crieList;
    }

    public List<Form> getFormList() {
        return formList;
    }

    public void setFormList(List<Form> formList) {
        this.formList = formList;
    }

    public List<Stat> getStats() {
        return stats;
    }

    public void setStats(List<Stat> stats) {
        this.stats = stats;
    }

    public List<Move> getMoves() {
        return moves;
    }

    public void setMoves(List<Move> moves) {
        this.moves = moves;
    }

    public Ability getAbility() {
        return ability;
    }

    public void setAbility(Ability ability) {
        this.ability = ability;
    }

    public void playChillar(boolean ultimo) {
        if (crieList== null) {
            System.out.println("❌ No hay sonido disponible para " + name);
            return;
        }

        String cryUrl = ultimo ? crieList.get(0).getLatest() : crieList.get(0).getLegacy();
        if (cryUrl == null || cryUrl.equals("N/A")) {
            System.out.println("❌ No se pudo obtener el sonido para " + name);
            return;
        }

        try {
            System.out.println("🔊 Reproduciendo sonido de " + name + ": " + cryUrl);
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(new URI(cryUrl).toURL());
            Clip clip = AudioSystem.getClip();
            clip.open(audioStream);
            clip.start();

        } catch (Exception e) {
            System.out.println("⚠️ Error al reproducir el sonido: " + e.getMessage());
        }
    }

    @Override
    public String toString() {
        return "Pokemon{" +
                "name='" + name + '\'' +
                ", id=" + id +
                ", height=" + height +
                ", weight=" + weight +
                ", type='" + type + '\'' +
                ", crieList=" + crieList +
                ", formList=" + formList +
                ", stats=" + stats +
                ", moves=" + moves +
                ", ability=" + ability +
                '}';
    }
}
