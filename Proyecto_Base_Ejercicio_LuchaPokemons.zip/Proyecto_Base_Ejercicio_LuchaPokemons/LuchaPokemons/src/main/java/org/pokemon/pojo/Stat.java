package org.pokemon.pojo;

public class Stat {
    private int baseStat;
    private StatDetail stat;

    public int getBaseStat() {
        return baseStat;
    }

    public void setBaseStat(int baseStat) {
        this.baseStat = baseStat;
    }

    public StatDetail getStat() {
        return stat;
    }

    public void setStat(StatDetail stat) {
        this.stat = stat;
    }

    public Stat(int baseStat, StatDetail stat) {
        this.baseStat = baseStat;
        this.stat = stat;
    }
}
