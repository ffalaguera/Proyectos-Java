package org.pokemon.pojo;

public class StatDetail {
    private String name;

    public StatDetail(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
