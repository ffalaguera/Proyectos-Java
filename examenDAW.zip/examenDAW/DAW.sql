CREATE TABLE empresa (
    id_empresa INT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    industria VARCHAR(50) NOT NULL,
    tipo VARCHAR(30) NOT NULL
);

CREATE TABLE oficina (
    id_oficina INT PRIMARY KEY,
    ciudad VARCHAR(50) NOT NULL,
    pais VARCHAR(50) NOT NULL,
    codigo_postal VARCHAR(20) NOT NULL,
    id_empresa INT NOT NULL,
    FOREIGN KEY (id_empresa) REFERENCES empresa(id_empresa)
);

CREATE TABLE empleado (
    id_empleado INT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    edad INT NOT NULL,
    puesto VARCHAR(50) NOT NULL,
    departamento VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    telefono VARCHAR(20) NOT NULL,
    id_empresa INT NOT NULL,
    id_oficina INT NOT NULL,
    FOREIGN KEY (id_empresa) REFERENCES empresa(id_empresa),
    FOREIGN KEY (id_oficina) REFERENCES oficina(id_oficina)
);

CREATE TABLE proyecto (
    id_proyecto INT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    id_empresa INT NOT NULL,
    id_empleado_responsable INT NOT NULL,
    fecha_inicio DATE NOT NULL,
    estado VARCHAR(30) NOT NULL,
    presupuesto DECIMAL(15,2) NOT NULL,
    FOREIGN KEY (id_empresa) REFERENCES empresa(id_empresa),
    FOREIGN KEY (id_empleado_responsable) REFERENCES empleado(id_empleado)
);