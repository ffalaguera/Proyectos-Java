package org.daw;
import org.daw.Parseador.recolectorDatos;
import org.daw.dao.EmpresaDAO;
import org.daw.pojo.Empresa;
import java.util.Comparator;
import java.util.List;
public class Main {
    public static void main(String[] args) {

        EmpresaDAO empresaDAO = new EmpresaDAO();

        //Esto te hará falta a la hora de trabajar con las fechas:

//        String fechaStr = ped.get("fecha").getAsString();
//        LocalDate fechaLocale = LocalDate.parse(fechaStr, DateTimeFormatter.ISO_LOCAL_DATE);
//        java.sql.Date fechaSql = java.sql.Date.valueOf(fechaLocale);

        //Si quiero insertar un dato de tipo fecha, pero esta fecha es un LocalDate en un tipo de datos, lo cogeré y pasaré así:

//        Date fecha = Date.valueOf(proyecto.getFecha_inicio().toString());
//        psInsertProyecto.setDate(5,fecha);


    }
}