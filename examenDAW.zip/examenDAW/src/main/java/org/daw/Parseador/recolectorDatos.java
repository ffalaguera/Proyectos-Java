package org.daw.Parseador;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.daw.dao.ConexionBD;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class recolectorDatos {
    private static final Gson gson = new Gson();

    // Método estático encargado de devolver un String
    private static String lectorJson(String ruta) {

    }

    // Método encargado de invocar al método anterior y ese String, lo parsea e
    // inserta en la base de datos.
    public void cargaDataBase(String ruta) {

    }


}
